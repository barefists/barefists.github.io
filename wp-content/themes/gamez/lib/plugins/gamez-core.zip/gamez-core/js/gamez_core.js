jQuery().ready(function($) {
    "use strict";

    // For recent-product shortcode and
    // Recent product VC Addon
    // =================================
    $(".gamez-recent-product .query-product").find('ul.products').addClass("owl-carousel").owlCarousel({
        pagination: true,
        dots:false,
        loop:true,
        items:1,
        nav: true,
        navClass: ['owl-carousel-left','owl-carousel-right'],
        navText: ['<i class="fa fa-angle-left fa-fw""></i>', '<i class="fa fa-angle-right fa-fw"></i>'],
        margin:20,
        autoplay:false,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:1
            },
            1000:{
                items:4
            }
        }
    });

    // ajax cart button animation
    //==============================
    $(document.body).on("adding_to_cart", function() {
        $('.cart-preloader').css({'display':'block'});
    });
    $(document.body).on("added_to_cart", function() {
        $('.cart-preloader').css({'display':'none'});
    });



});