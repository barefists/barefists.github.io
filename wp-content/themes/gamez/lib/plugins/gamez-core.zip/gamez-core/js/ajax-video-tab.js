jQuery().ready(function($){
    "use strict";
    $('.cpt-video-lists ul').find('li:first-child').addClass('active');

    $(function(){
        if(
            $('.cpt-video-lists ul').find('li:first-child').hasClass('active')
        )
        {
            var handle = $('.cpt-video-lists ul li.active').find('a');
            loadActiveData(handle);
        }
        $('.gamez-ajax-tab-wrapper ul li a').on( 'click',function(e) {
            e.preventDefault();
            $('.cpt-video-lists ul li').removeClass('active');
            $(this).parent().addClass('active');
            loadActiveData($(this));
        });
    });

    /**
     * ajax js function
     */
    function loadActiveData($handle){
        $('.loader').addClass('looading');
        var url = $handle.attr('href');
        $.ajax({
            url : url,
            type : 'post',
            //data : {
            //    action : 'user_clicked'
            //},
            success : function( html ) {
                $('#ajax-video-tab .video-single').remove();
                $('.loader').removeClass('looading');
                $('#ajax-video-tab').append(html);
                tab_owl();
            }
        });
        return false;
    }



    /**
     * add owl carousel
     */
    function tab_owl(){
        $('#ajax-video-tab').find('.video-single-gallery').addClass("owl-carousel").owlCarousel({
            pagination: true,
            dots:false,
            loop:true,
            items:2,
            nav: true,
            navClass: ['owl-carousel-left','owl-carousel-right'],
            navText: ['<i class="fa fa-angle-left fa-fw""></i>', '<i class="fa fa-angle-right fa-fw"></i>'],
            margin:10,
            autoplay:false,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:1
                },
                1000:{
                    items:1
                }
            }
        });
        /**
         * Magnific pop up for video
         */
        $('.popup-video, .popup-gmaps').magnificPopup({
            disableOn: 700,
            type: 'iframe',
            mainClass: 'mfp-fade',
            removalDelay: 160,
            preloader: false,
            fixedContentPos: false
        });
    }


});



