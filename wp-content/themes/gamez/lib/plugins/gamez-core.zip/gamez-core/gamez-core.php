<?php

/*
Plugin Name: Gamez Core
Plugin URI: http://www.themexpert.com
Description: Essential Plugin for Gamez Theme's Core functionality.
Version: 1.0
Author: ThemeXpert
Author URI: http://wwww.themexpert.com
License: GPLv2 or later
*/


// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 *
 * Plugin DocRoot absolute path without trailing slash
 *
 */

define( 'GAMEZ_CORE_ROOT', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

require GAMEZ_CORE_ROOT . '/inc/helper-functions.php';

require_once GAMEZ_CORE_ROOT . '/inc/post-type/class-tx-cpt.php';

require GAMEZ_CORE_ROOT . '/inc/post-type/gamez-cpts.php';

require GAMEZ_CORE_ROOT . '/inc/metabox/gamez-mb-review.php';
require GAMEZ_CORE_ROOT . '/inc/metabox/gamez-mb-video.php';
require GAMEZ_CORE_ROOT . '/inc/metabox/gamez-mb-page.php';

require_once GAMEZ_CORE_ROOT . '/inc/shortcodes/class-custom-registration.php';
require_once GAMEZ_CORE_ROOT . '/inc/shortcodes/class-shortcode-socialicon.php';
require_once GAMEZ_CORE_ROOT . '/inc/shortcodes/class-shortcode-socialshare.php';
require_once GAMEZ_CORE_ROOT . '/inc/shortcodes/class-shortcode-mailchimp.php';
require_once GAMEZ_CORE_ROOT . '/inc/shortcodes/class-shortcode-recentpost.php';
require_once GAMEZ_CORE_ROOT . '/inc/shortcodes/class-shortcode-review.php';
require_once GAMEZ_CORE_ROOT . '/inc/shortcodes/class-shortcode-video.php'; // shortcode for ajax video tab
require_once GAMEZ_CORE_ROOT . '/inc/shortcodes/class-shortcode-featuredproduct.php'; // shortcode for featured product
require_once GAMEZ_CORE_ROOT . '/inc/shortcodes/class-shortcode-recentproduct.php'; // shortcode for recent product
require_once GAMEZ_CORE_ROOT . '/inc/shortcodes/class-shortcode-bestsellingproduct.php'; // shortcode for best selling product
require_once GAMEZ_CORE_ROOT . '/inc/shortcodes/class-shortcode-title.php';
require_once GAMEZ_CORE_ROOT . '/inc/ajax-functions.php';

require_once GAMEZ_CORE_ROOT . '/inc/class-vc_map.php';


/**
 * Load plugin
 *
 * Load the text domain and hook up the CPTs
 *
 */

function gamez_core_load() {

    // Load text domain
    load_plugin_textdomain( 'gamez', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

    // Shortcodes are awesome
    Gamez_Shortcode_Social::init();
    Gamez_Shortcode_SocialShare::init();
    Gamez_Shortcode_MailChimp::init();
    Gamez_Shortcode_Recent_Post::init();
    Gamez_Shortcode_Review::init();
    Gamez_Video_Tab::init(); // class - ajax video tab
    Gamez_Featured_Product::init(); // class - Featured Product
    Gamez_Recent_Product::init(); // class - Recent Product
    Gamez_Bestselling_Product::init(); // class - Best selling Product
    Gamez_Custom_Login::init(); // class - custom registration form
    Gamez_Shortcode_Title::init();


}

add_action( 'plugins_loaded', 'gamez_core_load' );

/**
 *
 * Flush rewrite rules on plugin activation/deactivation
 *
 */

function gamez_core_flush() {
    flush_rewrite_rules();
}

register_activation_hook( __FILE__, 'gamez_core_flush' );
register_deactivation_hook( __FILE__, 'gamez_core_flush' );

function gamez_plugin_scripts() {
    wp_enqueue_script('gamez_ajax_video_tab', plugin_dir_url(__FILE__) . 'js/ajax-video-tab.js', array('jquery'), '1.0');
    wp_enqueue_script('gamez_gamez_core', plugin_dir_url(__FILE__) . 'js/gamez_core.js', array('jquery'), '1.1');
}
add_action( 'wp_enqueue_scripts', 'gamez_plugin_scripts' );