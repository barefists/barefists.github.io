<?php

add_filter( 'widget_text', 'do_shortcode' );
