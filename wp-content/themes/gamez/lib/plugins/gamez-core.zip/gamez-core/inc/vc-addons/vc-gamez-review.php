<?php


$gamez_review_mapper = array(
    "name" => __("Reviews", 'gamez'),
    "description" => __("Display Reviews.", 'gamez'),
    "base" => "gamez-review",
    "class" => "",
    "controls" => "full",
    "icon" => $icon,
    "category" => $category,
    "params" => array(

        array(
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __("Style", 'gamez'),
            "param_name" => "style",
            "value" => array(
                __("Carousel", 'gamez') => 'carousel',
                __("Grid", 'gamez')  => 'grid'
            ),
            "description" => __("Display Reviews in your style.", 'gamez'),

        ),
        array(
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __("Order", 'gamez'),
            "param_name" => "order",
            "value" => $value_asc_desc,
            "description" => __("Display Reviews in Ascending or descending order.", 'gamez'),

        ),

        array(
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __("Order By", 'gamez'),
            "param_name" => "orderby",
            "value" => array(
                __("Popular", 'gamez') => 'comment_count',
                __("Title", 'gamez') => 'title',
                __("Name", 'gamez')  => 'name',
                __("Date", 'gamez')  => 'date',
                __("Random", 'gamez')   => 'rand',
            ),
            "description" => __("Display Reviews in order by.", 'gamez'),

        ),

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Post Item", 'gamez'),
            "param_name" => "item",
            "value" => 3,
            "description" => __("Total Event number to display. For displaying all input -1. Default is 3.", 'gamez'),

        ),


    )
);