<?php
/**
 *
 * Quick Info Shortcode
 *
 */


class Gamez_Shortcode_Title {


    /**
     *
     * Shortcode Name
     * @var string
     */

    private $name = 'gamez-title';


    /**
     * Instance of class
     */
    private static $instance;

    /**
     * Initialization
     */
    public static function init() {
        if ( null === self::$instance ) {
            self::$instance = new self;
        }

        return self::$instance;
    }


    private function __construct() {

        add_shortcode( $this->name, array( $this, 'create_gamez_title_shortcode' ) );
    }


    /**
     * Shortcode Function
     *
     * @param $atts
     * @return string
     */

    public function create_gamez_title_shortcode( $atts ) {

        ob_start();

        $default = array(
            'icon' => '',
            'tag' => 'h2',
            'title' => '',
            'icon-color' => '#00d5e3',
            'text-color' => '#fff',
            'css' => ''
        );

        $info = shortcode_atts( $default, $atts );
        $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $info ['css'], ' ' ), $this->name, $info );
        ?>


        <<?php echo $info['tag']; ?> class="<?php echo $css_class; ?>" style="color:<?php  echo $info['text-color'];?>;"><i class="gamez-section-title-icon <?php echo $info['icon']; ?>" style="color:<?php  echo $info['icon-color'];?>;"></i><?php echo $info['title']; ?></<?php echo $info['tag']; ?>>


        <?php
        $output = ob_get_clean();

        return $output;

    }

}