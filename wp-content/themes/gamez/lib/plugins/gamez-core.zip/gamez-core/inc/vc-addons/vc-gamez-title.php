<?php



$gamez_title_mapper = array(
    "name" => __("Section Title", 'gamez'),
    "description" => __("Section Tile with Icon.", 'gamez'),
    "base" => "gamez-title",
    "class" => "",
    "controls" => "full",
    "icon" => $icon,
    "category" => $category,
    "params" => array(
        array(
            "type" => "iconpicker",
            "holder" => "div",
            "class" => "",
            "heading" => __("Icon", 'gamez'),
            "param_name" => "icon",
            'settings'   => array(
                'emptyIcon'    => true,
                'iconsPerPage' => 200
            ),
            "value" => '',
            "description" => __("Title Icon.", 'gamez'),

        ),

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Title", 'gamez'),
            "param_name" => "title",
            "value" => '',
            "description" => __("Section Title Text.", 'gamez'),

        ),

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Tag", 'gamez'),
            "param_name" => "tag",
            "value" => '',
            "description" => __("Header tag like h1, h2 etc.", 'gamez'),

        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Icon Color", 'gamez' ),
            "param_name" => "icon-color",
            "value" => '#00d5e3',
            "description" => __( "Choose Icon Color", 'gamez' )
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Text Color", 'gamez' ),
            "param_name" => "text-color",
            "value" => '#fff',
            "description" => __( "Choose Text Color", 'gamez' )
        ),

        array(
            'type' => 'css_editor',
            'heading' => __( 'CSS', 'gamez' ),
            'param_name' => 'css',
            'group' => __( 'Design Options', 'gamez' ),
        ),

    )
);
