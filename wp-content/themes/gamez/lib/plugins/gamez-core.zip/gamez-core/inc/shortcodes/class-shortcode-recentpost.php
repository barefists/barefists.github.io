<?php
/**
 *
 * Recent Post Shortcode
 *
 */


class Gamez_Shortcode_Recent_Post {


    /**
     *
     * Shortcode Name
     * @var string
     */

    private $name = 'gamez-recent-post';

    private $post_type = 'post';

    /**
     * Instance of class
     */
    private static $instance;

    /**
     * Initialization
     */
    public static function init() {
        if ( null === self::$instance ) {
            self::$instance = new self;
        }

        return self::$instance;
    }


    private function __construct() {

        add_shortcode( $this->name, array( $this, 'create_recent_post_shortcode' ) );
    }




    /**
     * Shortcode Function
     *
     * @param $atts
     * @return string
     */

    public function create_recent_post_shortcode( $atts ) {

        ob_start();

        $option = array(
            'item' => 5,
            'order' => 'DESC',
            'orderby' => 'date',
            'category' => ''

        );

        $s = shortcode_atts( $option, $atts );

        $args = array(
            'post_type' => $this->post_type,
            'order' => $s['order'],
            'orderby' => $s['orderby'],
            'category_id' => $s['category'],
            'posts_per_page' => $s['item'],
            'post__not_in' => get_option( 'sticky_posts' ),
        );

        $q = new WP_Query( $args );

        if ( $q->have_posts() ): ?>

            <?php  while ( $q->have_posts() ): $q->the_post(); ?>

                <div class="gamez-recent-with-thumb">
                    <div class="media">
                        <?php if( has_post_thumbnail() ): ?>
                        <div class="media-left">
                            <figure>
                                <?php the_post_thumbnail('medium'); ?>
                            </figure>
                        </div>
                        <?php endif; ?>
                        <div class="media-body">
                            <h4 class="media-heading"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> </h4>
                            <div class="content-desc">
                                <?php echo wp_trim_words(get_the_content(), 20); ?>
                                <div class="content-meta">
                                    <span><i class="fa fa-calendar"></i> <?php echo esc_html( get_the_date( 'F' )). ' ' . esc_html( get_the_date( 'd' )) . ', ' . esc_html( get_the_date( 'Y' ));?></span>
                                    <?php echo '<span class="comments-link" title="'.esc_attr__( '0 Comment', 'gamez' ).'"><i class="fa fa-comment"></i> ';
                                    comments_popup_link( esc_html__( '0 Comment', 'gamez' ), esc_html__( '1 Comment', 'gamez' ), esc_html__( '% Comments', 'gamez' ) );
                                    echo '</span>'; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            <?php endwhile; wp_reset_postdata(); ?>



        <?php else: ?>

            <p> <?php esc_html_e( 'Sorry, no post found.', 'gamez' ); ?> </p>

        <?php    endif;
        $output = ob_get_clean();

        return $output;

    }



}