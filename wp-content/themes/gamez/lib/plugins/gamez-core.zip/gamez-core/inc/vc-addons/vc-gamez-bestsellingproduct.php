<?php

/*
* vc addon for recent product
*/

/**
 * @var no_product
 * @var bg_img
 * @var slug
 * @var size
 */


$vc_gamez_bestselling_product = array(
    'name'				=> __('Best Selling Product', 'gamez'),
    'description'		=> __('Display woocommerce Best Selling product', 'gamez'),
    'base'				=> 'bestselling-product',
    'class'				=> '',
    'controls'			=> 'full',
    'icon'				=> $icon,
    'category'			=> $category,
    'params'			=> array(
        array(
            'type'		=> 'textfield',
            'holder'	=> 'div',
            'class'		=> '',
            'heading'		=> __('Write Section Heading', 'gamez'),
            'param_name'	=> 'heading',
            'value'			=> '',
            'description'	=> __('Write your section heading', 'gamez')
        ),
        array(
            'type'		=> 'textfield',
            'holder'	=> 'div',
            'class'		=> '',
            'heading'		=> __('Number of product', 'gamez'),
            'param_name'	=> 'no-of-product',
            'value'			=> '',
            'description'	=> __('Number of product to show ', 'gamez')
        ),

    )
);




