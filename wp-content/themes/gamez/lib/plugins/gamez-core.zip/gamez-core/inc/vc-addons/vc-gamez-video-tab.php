<?php
$gamez_video_tab = array(
    'name'				=> __('Ajax video Tab', 'gamez'),
    'description'		=> __('Display Video List', 'gamez'),
    'base'				=> 'video-tab',
    'class'				=> '',
    'controls'			=> 'full',
    'icon'				=> $icon,
    'category'			=> $category,
    'params'			=> array(
        // params group
        array(
            'type'			=> 'textfield',
            'holder'		=> 'div',
            'class'			=> '',
            'heading'		=> __('Video list to show', 'gamez'),
            'param_name'	=> 'no_video_tab',
            'value'			=> '',
            'description'	=> __('How many video you want to show', 'gamez')
        ),
        array(
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __("Tab style type", 'gamez'),
            "param_name" => "type",
            "value" => array(
                __("Horizontal", 'gamez') => 'horizontal',
                __("Vertical", 'gamez')  => 'vertical',
            ),
            'save_always' => true,
            "description" => __("Select you tab style type", 'gamez'),

        ),
    )
);