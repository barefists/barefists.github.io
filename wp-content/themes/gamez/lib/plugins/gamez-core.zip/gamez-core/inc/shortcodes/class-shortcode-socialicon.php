<?php
/**
 *
 * Social Share Shortcode
 *
 */


class Gamez_Shortcode_Social {


    /**
     *
     * Shortcode Name
     * @var string
     */

    private $name = 'gamez-social';


    /**
     * Instance of class
     */
    private static $instance;

    /**
     * Initialization
     */
    public static function init() {
        if ( null === self::$instance ) {
            self::$instance = new self;
        }

        return self::$instance;
    }


    private function __construct() {

        add_shortcode( $this->name, array( $this, 'create_social_shortcode' ) );
    }


    /**
     * Shortcode Function
     *
     * @param $atts
     * @return string
     */

    public function create_social_shortcode( ) {

        $show_social = cs_get_option('tx_social_icons'); //returns boolean value (true)
        $social_links = cs_get_option('tx_top_social'); //returns 2D Array
        $social_fb = $social_links['tx_top_social_fb']; //returns Social Link (facebook)
        $social_tw = $social_links['tx_top_social_tw']; //returns Social Link (twitter)
        $social_yt = $social_links['tx_top_social_yt']; //returns Social Link (youtube)
        $social_ln = $social_links['tx_top_social_ln']; //returns Social Link (linkedin)
        $social_gp = $social_links['tx_top_social_gp']; //returns Social Link (google plus)
        $social_vm = $social_links['tx_top_social_vm']; //returns Social Link
        $social_tch = $social_links['tx_top_social_tch']; //returns Social Link


        ob_start();

        ?>



        <div class="gamez-social-icons">
            <?php if (!empty($social_fb)): ?>
                <a class="icon-set" href="<?php echo esc_url($social_fb); ?>" target="_blank"><i
                        class="fa fa-facebook"></i></a>
            <?php endif; ?>

            <?php if (!empty($social_tw)): ?>
                <a class="icon-set" href="<?php echo esc_url($social_tw); ?>" target="_blank"><i
                        class="fa fa-twitter"></i></a>
            <?php endif; ?>

            <?php if (!empty($social_ln)): ?>
                <a class="icon-set" href="<?php echo esc_url($social_ln); ?>" target="_blank"><i
                        class="fa fa-linkedin"></i></a>
            <?php endif; ?>

            <?php if (!empty($social_yt)): ?>
                <a class="icon-set" href="<?php echo esc_url($social_yt); ?>" target="_blank"><i
                        class="fa fa-youtube"></i></a>
            <?php endif; ?>

            <?php if (!empty($social_gp)): ?>
                <a class="icon-set" href="<?php echo esc_url($social_gp); ?>" target="_blank"><i
                        class="fa fa-google-plus"></i></a>
            <?php endif; ?>

            <?php if (!empty($social_vm)): ?>
                <a class="icon-set" href="<?php echo esc_url($social_vm); ?>" target="_blank"><i
                        class="fa fa-vimeo"></i></a>
            <?php endif; ?>

            <?php if (!empty($social_tch)): ?>
                <a class="icon-set" href="<?php echo esc_url($social_tch); ?>" target="_blank"><i
                        class="fa fa-twitch"></i></a>
            <?php endif; ?>
        </div>

        <?php    $output = ob_get_clean();

        return $output;

    }


}