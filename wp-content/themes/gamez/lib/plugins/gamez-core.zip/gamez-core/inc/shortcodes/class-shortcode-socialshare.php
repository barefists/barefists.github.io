<?php
/**
 *
 * Social Share Shortcode
 *
 */


class Gamez_Shortcode_SocialShare {


    /**
     *
     * Shortcode Name
     * @var string
     */

    private $name = 'gamez-share';


    /**
     * Instance of class
     */
    private static $instance;

    /**
     * Initialization
     */
    public static function init() {
        if ( null === self::$instance ) {
            self::$instance = new self;
        }

        return self::$instance;
    }


    private function __construct() {

        add_shortcode( $this->name, array( $this, 'create_socialshare_shortcode' ) );
    }


    /**
     * Shortcode Function
     *
     * @param $atts
     * @return string
     */

    public function create_socialshare_shortcode( $atts ) {



        $default = array(
            's_facebook' => 'yes',
            's_twitter' => 'yes',
            's_linkedin' => 'yes',
            's_gplus' => 'yes',
        );

        $s = shortcode_atts( $default, $atts );

        remove_filter( 'the_title', 'wptexturize' );

        $gamez_title = urlencode(html_entity_decode(get_the_title()));

        add_filter( 'the_title', 'wptexturize' );

        remove_filter( 'the_excerpt', 'wptexturize' );

        $gamez_excerpt = urlencode(html_entity_decode(get_the_excerpt()));

        add_filter( 'the_excerpt', 'wptexturize' );

        $gamez_url = urlencode( get_permalink() );



        // Construct sharing URL without using any script

        $twitter_url = 'https://twitter.com/intent/tweet?text='.$gamez_title.'&amp;url='.$gamez_url;
        $facebook_url = 'https://www.facebook.com/sharer/sharer.php?u='.$gamez_url;
        $google_url = 'https://plus.google.com/share?url='.$gamez_url;
        $linked_url = 'https://www.linkedin.com/shareArticle?mini=true&url='.$gamez_url.'&title='.$gamez_title.'&summary='.$gamez_excerpt;


        ob_start();

        ?>



        <div class="gamez-social-share">
            <?php if( $s['s_facebook'] == 'yes' ): ?>
                <a href="<?php echo $facebook_url; ?>" target="_blank"><i class="fa fa-facebook fa-fw"></i></a>
            <?php endif; ?>
            <?php if( $s['s_twitter'] == 'yes' ): ?>
                <a href="<?php echo $twitter_url; ?>" target="_blank"><i class="fa fa-twitter fa-fw"></i></a>
            <?php endif; ?>
            <?php if( $s['s_linkedin'] == 'yes' ): ?>
                <a href="<?php echo $linked_url; ?>" target="_blank"><i class="fa fa-linkedin fa-fw"></i></a>
            <?php endif; ?>
            <?php if( $s['s_gplus'] == 'yes' ): ?>
                <a href="<?php echo $google_url; ?>" target="_blank"><i class="fa fa-google-plus fa-fw"></i></a>
            <?php endif; ?>
        </div>

        <?php    $output = ob_get_clean();

        return $output;

    }


}