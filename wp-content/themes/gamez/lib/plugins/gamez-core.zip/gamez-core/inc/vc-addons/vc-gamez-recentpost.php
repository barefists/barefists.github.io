<?php

function gamez_get_post_category() {
    $cat = array();
    $terms = get_terms( array(
        'taxonomy' => 'category',
        'hide_empty' => false,
        'fields'   => 'id=>name'
    ) );
    foreach ($terms as $key => $value) {
        $cat[ucwords($value)] = $key;
    }
    return $cat;
}

$gamez_recent_post_mapper = array(
    "name" => __("Recent Posts", 'gamez'),
    "description" => __("Display Recent Posts with thumbnail.", 'gamez'),
    "base" => "gamez-recent-post",
    "class" => "",
    "controls" => "full",
    "icon" => $icon,
    "category" => $category,
    "params" => array(
        array(
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __("Order", 'gamez'),
            "param_name" => "order",
            "value" => $value_asc_desc,
            "description" => __("Display Recent Posts in Ascending or descending order.", 'gamez'),

        ),

        array(
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __("Order By", 'gamez'),
            "param_name" => "orderby",
            "value" => array(
                __("Title", 'gamez') => 'title',
                __("Name", 'gamez')  => 'name',
                __("Date", 'gamez')  => 'date',
                __("Random", 'gamez')   => 'rand',
            ),
            "description" => __("Display Recent Posts in order by.", 'gamez'),

        ),

        array(
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __("Category", 'gamez'),
            "param_name" => "category",
            "value" => gamez_get_post_category(),
            "description" => __("Display Recent Posts from category.", 'gamez'),

        ),

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Post Item", 'gamez'),
            "param_name" => "item",
            "value" => 2,
            "description" => __("Total Post number to display. For displaying all input -1. Default is 2.", 'gamez'),

        ),


    )
);