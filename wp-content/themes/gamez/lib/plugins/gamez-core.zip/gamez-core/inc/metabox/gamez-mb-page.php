<?php

/**
 *
 * General Page Metabox
 *
 */


function gamez_page_metabox( $options ){


    $options[]    = array(
        'id'        => '_tx_page_meta',
        'title'     => __('Page Header', 'gamez'),
        'post_type' => 'page',
        'context'   => 'normal',
        'priority'  => 'default',
        'sections'  => array(

            array(
                'name'   => '_tx_page_header',
                'title' => __('Page Header Options', 'gamez'),
                'icon'  => 'fa fa-icon-bookmark-empty',
                'fields' => array(

                    array(
                        'id'            => '_tx_page_header_image',
                        'type'          => 'image',
                        'title'         => __('Header Image', 'gamez'),
                        'desc'       => __( 'Add Header Image', 'gamez' ),
                    ),

                ),
            ),

        ),
    );

    return $options;

}


add_filter( 'cs_metabox_options',  'gamez_page_metabox');

