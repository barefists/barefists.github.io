<?php
$args = array(
    'post_type' => 'product',
    'meta_key' => '_featured',
    'meta_value' => 'yes',
);
$query = new WP_Query($args);
$featured_products = array();
foreach($query->posts as $post){
    $featured_products[$post->post_title] = $post->ID;
}

$vc_gamez_feaured_product = array(
    'name' 				=> __('Featured Product', 'gamez'),
    'description'		=> __('Featured Product', 'gamez'),
    'base'				=> 'featured-product',
    'class'				=> '',
    'controls'			=> 'full',
    'icon'              => $icon,
    'category'          => $category,
    'params'			=> array(

        array(
            'type'		=> 'dropdown',
            'holder'	=> 'div',
            'class'		=> '',
            'heading'		=> __('Featured Product', 'gamez'),
            'param_name'	=> 'id',
            'value'			=> $featured_products,
            'description'	=> __('Choose your featured product to show', 'gamez')
        ),
    ),
);
