<?php
/*
* Woocommerce show category
*/
class Gamez_Recent_Product{
    /**
     * Name of the shortcode
     * @var string
     */
    private $name = 'recent-product';
    private static $instance;

    /**
     * Shortcode initialization
     * @return Mebel_featured_product
     */
    public static function init(){
        if(null == self::$instance){
            self::$instance = new self;
        }
        return self::$instance;
    }

    /**
     * Shortcode construct
     * Mebel_featured_product constructor.
     */
    private function __construct(){
        add_shortcode($this->name, array($this, 'gamez_recent_product'));
    }


    public function gamez_recent_product($atts){

        ob_start();
        $option = array(
            'heading'	=> '',
            'no-of-product' => '',
        );


        global $product;
        $recent_product = shortcode_atts( $option, $atts );

        ?>

        <?php if(class_exists('woocommerce')): ?>
        <div class="gamez-product">
            <div class="col-md-12 gamez-recent-product">
                <div class="gamez-recent-product-wrapper">
                    <?php
                    $args = array(
                        'post_type' => 'product',
                        'stock' => 1,
                        'posts_per_page' => $recent_product['no-of-product'],
                        'orderby' =>'date',
                        'order' => 'DESC'
                    );
                    ?>
                    <?php $query = new WP_Query($args); ?>

                    <?php if ($query->have_posts()) :?>
                        <div class="query-product">
                            <div class="woocommerce">
                                <div class="product-header">
                                    <h2><?php echo $recent_product['heading']; ?></h2>
                                </div>
                                <ul class="products">
                                    <?php while( $query->have_posts() ): $query->the_post(); ?>

                                        <li class="product-item">

                                            <?php
                                            /**
                                             * woocommerce_before_shop_loop_item hook.
                                             *
                                             * @hooked woocommerce_template_loop_product_link_open - 10
                                             */
                                            do_action( 'woocommerce_before_shop_loop_item' );

                                            /**
                                             * woocommerce_before_shop_loop_item_title hook.
                                             *
                                             * @hooked woocommerce_show_product_loop_sale_flash - 10
                                             * @hooked woocommerce_template_loop_product_thumbnail - 10
                                             */
                                            do_action( 'woocommerce_before_shop_loop_item_title' );

                                            /**
                                             * woocommerce_shop_loop_item_title hook.
                                             *
                                             * @hooked woocommerce_template_loop_product_title - 10
                                             */
                                            do_action( 'woocommerce_shop_loop_item_title' );

                                            /**
                                             * woocommerce_after_shop_loop_item_title hook.
                                             *
                                             * @hooked woocommerce_template_loop_rating - 5
                                             * @hooked woocommerce_template_loop_price - 10
                                             */
                                            do_action( 'woocommerce_after_shop_loop_item_title' );

                                            /**
                                             * woocommerce_after_shop_loop_item hook.
                                             *
                                             * @hooked woocommerce_template_loop_product_link_close - 5
                                             * @hooked woocommerce_template_loop_add_to_cart - 10
                                             */
                                            do_action( 'woocommerce_after_shop_loop_item' );
                                            ?>
                                            <div class="product-meta-information">
                                                <div class="product-permalink">
                                                    <a href="<?php echo the_permalink(); ?>">
                                                        <?php do_action('gamez_shop_loop_item_meta'); ?>
                                                    </a>
                                                </div>
                                                <?php do_action('gamez-cart'); ?>
                                            </div>
                                            <div class="product-sale">
                                                <?php do_action('gamez-product-sale') ?>
                                            </div>

                                        </li>


                                    <?php endwhile; ?>
                                </ul>
                                <!--				end of the /ul-->
                            </div>
                            <!--                            end of the /.tab_featured_product-->
                        </div>
                        <!-- end of the /.tab_featured_product_wrapper -->
                    <?php else: ?>
                        <div class="no-featured-product">
                            <?php echo 'sorry there is no featured product in this category'; ?>
                        </div>
                        <?php
                    endif;
                    wp_reset_query();?>


                </div>
            </div>
            <!-- end of the /.wooshop_featured_wrapper -->
        </div>
        <!-- end of the div/#woosome_featured_shoppage -->
        <?php else: ?>
            <div class="woocommerce-red-alert">
                <h2>
                    please active your woocommerce plugin
                </h2>
                <p>Otherwise, You may download Woocommerce plugin <a href="https://wordpress.org/plugins/woocommerce/">From Here</a></p>
            </div>
        <?php endif; ?>

        <?php

        $output = ob_get_clean();
        return $output;
    }

}