<?php

/**
 * Video Gallery Metabox
 */

function gamez_video_gallery_metabox( $options ) {

    $options[]    = array(
        'id'        => '_tx_video_gallery',
        'title'     => __('Gallery Information', 'gamez'),
        'post_type' => 'video_gallery',
        'context'   => 'normal',
        'priority'  => 'default',
        'sections'  => array(

            array(
                'name'   => '_tx_video_gallery_name',
                'title'  => __('Videos', 'gamez'),
                'fields' => array(
                    array(
                        'id'              => '_tx_video_galleries',
                        'type'            => 'group',
                        'title'           => __('Video Gallery', 'gamez'),
                        'button_title'    => __('Add New', 'gamez'),
                        'accordion_title' => __('Add New Video', 'gamez'),
                        'fields'          => array(
                            array(
                                'id'    => '_tx_video_gallery_link',
                                'type'  => 'text',
                                'title' => __('Video Link', 'gamez'),
                                'desc'  => __('Enter vimeo or youtube video link.', 'gamez')
                            ),
                            array(
                                'id'    => '_tx_video_gallery_cover',
                                'type'  => 'image',
                                'title' => __('Video Cover', 'gamez'),
                                'desc'  => __('Upload video cover image.', 'gamez')
                            ),

                        )
                    ),
                )
            ),

        ) );

    return $options;
}

add_filter( 'cs_metabox_options',  'gamez_video_gallery_metabox');