<?php
/**
 *
 * Mailchimp Form Shortcode
 *
 */


class Gamez_Shortcode_MailChimp {


    /**
     *
     * Shortcode Name
     * @var string
     */

    private $name = 'gamez-chimp';


    /**
     * Instance of class
     */
    private static $instance;

    /**
     * Initialization
     */
    public static function init() {
        if ( null === self::$instance ) {
            self::$instance = new self;
        }

        return self::$instance;
    }


    private function __construct() {

        add_shortcode( $this->name, array( $this, 'create_mailchimp_shortcode' ) );
    }


    /**
     * Shortcode Function
     *
     * @param $atts
     * @return string
     */

    public function create_mailchimp_shortcode( $atts ) {

        ob_start();

        $data = shortcode_atts( array(
            'title'       => '',
            'action'      => '',
            'label_email' => '',
        ), $atts );

        $title       = ( '' === $data['title'] ) ? '' : esc_html( $data['title'] );
        $action      = ( '' === $data['action'] ) ? '' : esc_url_raw( htmlspecialchars_decode( $data['action'] ) );
        $label_email = ( '' === $data['label_email'] ) ? __( 'Your Email', 'gamez' ) : esc_html( $data['label_email'] );



        // If action not set, just exit
        if ( '' === $action ) {
            return;
        }


        // Title

        if ( '' !== $title ) {
            $title = sprintf( '<h3>%s</h3>', $title );
        } ?>

        <form method="post" class="gamez-mailchimp" action="<?php echo $action; ?>" autocomplete="off" target="_blank">
            <?php echo $title; ?>


            <div class="form-group">
                <input type="email" class="form-control" name="<?php esc_attr_e($label_email); ?>" placeholder="<?php esc_attr_e($label_email); ?>" required>
                <button type="submit" class="gamez-btn"><i class="fa fa-paper-plane fa-fw"></i></button>
            </div>

        </form>

        
        <?php
        $output = ob_get_clean();

        return $output;

    }






}