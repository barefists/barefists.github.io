<?php

/*
* Featured Product Image
*/
class Gamez_Featured_Product{

    private $name = 'featured-product';

    private static $instance;

    // initialization
    #================
    public static function init(){
        if(null == self::$instance){
            self::$instance = new self;
        }
        return self::$instance;
    }

    // construct
    private function __construct(){
        add_shortcode($this->name, array($this, 'gamez_featured_product'));
    }


    public function gamez_featured_product($atts){
        global $post, $product;
        ob_start();
        $option = array(
            'id'  => ''
        );

        $featured = shortcode_atts( $option, $atts );
        $args = array(
            'post_type' => 'product',
            'p'    => $featured['id'],
        );
        $query = new WP_Query($args);

        ?>
        <?php if(class_exists('woocommerce')): ?>
        <div class="gamez-featured-product">
            <div class="gamez-featured-product-container">

                <?php if ($query->have_posts()) :?>
                    <?php while ($query->have_posts()) :?>
                        <?php $query->the_post(); ?>
                        <?php
                        $img_id = get_the_ID();
                        $product_header_image = get_post_meta($img_id,'_tx_product_meta', true);
                        $product_header_image = gamez_array_get($product_header_image,'_tx_product_header_image');
                        $product_header_image = wp_get_attachment_image_src($product_header_image, 'full');
                        $product_header_image = $product_header_image[0];
                        ?>
                        <div class="gamez-featured-product-wrapper" style="
                            background:url(<?php echo $product_header_image ?>);
                            background-attachment: fixed;
                            background-size:cover;
                            background-position: left center;
                            ">
                        <div class="product-header-image" >
                            <?php if(has_post_thumbnail()): ?>
                                <?php the_post_thumbnail('medium'); ?>
                            <?php endif; ?>
                        </div>
                        <div class="query-product woocommerce">
                            <div class="query-product-wrapper">

                                <div class="product-rating">
                                    <?php do_action('gamez_single_product_rating'); ?>
                                </div>
                                <h1 class="product-title">
                                    <a href="<?php the_permalink();?>"><?php the_title(); ?></a>
                                </h1>
                                <div class="product-excerpt">
                                    <?php echo wp_trim_words( get_the_excerpt(), $num_words = 20, $more = null ); ?>
                                </div>
                                <div class="product-cart-button">
                                    <?php do_action('gamez-cart'); ?>
                                </div>
                            </div>
<!--                                end of /.query-product-wrapper-->
                        </div>
                        <!-- end of the /.query-product -->
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="no-featured-product">
                        <?php echo 'sorry there is no featured product in this category'; ?>
                    </div>
                    <?php
                endif;
                wp_reset_query();?>

            </div>
            <!-- end of the /.gamez-featured-product-wrapper -->
        </div>
        <!-- end of the div/#gamez-featured-product -->
        <?php else: ?>
            <div class="woocommerce-red-alert">
                <h2>
                    please active your woocommerce plugin
                </h2>
                <p>Otherwise, You may download Woocommerce plugin <a href="https://wordpress.org/plugins/woocommerce/">From Here</a></p>
            </div>
        <?php endif; ?>
        <?php

        $output = ob_get_clean();
        return $output;
    }

}