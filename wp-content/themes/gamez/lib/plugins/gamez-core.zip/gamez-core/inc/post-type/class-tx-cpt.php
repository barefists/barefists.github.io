<?php

/**
*
* Implimentation:
*
*
* $arg = array('feature_image', 'Postforu');
* $book = new Tx_Custom_Post_Type('Book', $arg, $labels, $text_domain);
* $book->add_taxonomy( 'author' );
*
*/

class Tx_Custom_Post_Type {
    public $post_type_name;
    public $post_type_args;
    public $post_type_labels;
    public $text_domain;
     
    /* Class constructor */
    public function __construct( $name, $args = array(), $labels = array(), $domain ) {
        // Set some important variables
        $this->post_type_name        = self::uglify( $name );
        $this->post_type_args        = $args;
        $this->post_type_labels      = $labels;
        $this->text_domain           = $domain;
         
        // Add action to register the post type, if the post type does not already exist
        if( ! post_type_exists( $this->post_type_name ) ){
            add_action( 'init', array( $this, 'register_post_type' ) );
        }
         
        // Listen for the save post hook
        //$this->save();
    }
     
    /* Method which registers the post type */
    public function register_post_type(){
        //Capitilize the words and make it plural
        $name       = self::beautify( $this->post_type_name );
        $plural     = self::pluralize( $name );
        $text_domain = $this->text_domain;
         
        // We set the default labels based on the post type name and plural. We overwrite them with the given labels.
        $labels = array_merge(
     
            // Default
            array(
                'name'                  => _x( $plural, 'Post Type General Name', $text_domain ),
                'singular_name'         => _x( $name, 'Post Type Singular Name', $text_domain ),
                'menu_name'             => __( $plural, $text_domain ),
                'name_admin_bar'        => __( $plural, $text_domain ),
                'archives'              => __( $name . ' Archives', $text_domain ),
                'parent_item_colon'     => __( 'Parent '. $name .':', $text_domain ),
                'all_items'             => __( 'All '. $plural, $text_domain ),
                'add_new_item'          => __( 'Add New '. $name, $text_domain ),
                'add_new'               => __( 'Add New', $text_domain ),
                'new_item'              => __( 'New '. $name, $text_domain ),
                'edit_item'             => __( 'Edit '. $name, $text_domain ),
                'update_item'           => __( 'Update '. $name, $text_domain ),
                'view_item'             => __( 'View '. $name, $text_domain ),
                'search_items'          => __( 'Search '. $name, $text_domain ),
                'not_found'             => __( 'No ' . strtolower( $plural ) . ' found', $text_domain ),
                'not_found_in_trash'    => __( 'No ' . strtolower( $plural ) . ' found in Trash', $text_domain ),
                'featured_image'        => __( 'Featured Image', $text_domain ),
                'set_featured_image'    => __( 'Set featured image', $text_domain ),
                'remove_featured_image' => __( 'Remove featured image', $text_domain ),
                'use_featured_image'    => __( 'Use as featured image', $text_domain ),
                'insert_into_item'      => __( 'Insert into '. $name, $text_domain ),
                'uploaded_to_this_item' => __( 'Uploaded to this '. $name, $text_domain ),
                'items_list'            => __( $plural . ' list', $text_domain ),
                'items_list_navigation' => __( $plural . ' list navigation', $text_domain ),
                'filter_items_list'     => __( 'Filter ' . strtolower( $plural ) . ' list', $text_domain ),
            ),
             
            // Given labels
            $this->post_type_labels
         
        );
     
    // Same principle as the labels. We set some defaults and overwrite them with the given arguments.
        $args = array_merge(
         
            // Default
            array(
                'label'                 => __( $plural, $text_domain ),
                'description'           => __( 'Taxonomy description.', $text_domain ),
                'labels'                => $labels,
                'supports'              => array( 'title', 'editor', 'thumbnail' ),
                'taxonomies'            => array( ),
                'hierarchical'          => false,
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 25,
                'menu_icon'             => 'dashicons-welcome-learn-more',
                'show_in_admin_bar'     => true,
                'show_in_nav_menus'     => true,
                'can_export'            => true,
                'has_archive'           => true,
                'exclude_from_search'   => false,
                'publicly_queryable'    => true,
                'capability_type'       => 'page',
                'rewrite'               => true,
            ),
             
            // Given args
            $this->post_type_args
             
        );
     
        // Register the post type
        register_post_type( $this->post_type_name, $args );
         
    }
     
    /* Method to attach the taxonomy to the post type */
    public function add_taxonomy( $name, $args = array(), $labels = array()) {
        if( ! empty( $name ) ) {
            // We need to know the post type name, so the new taxonomy can be attached to it.
            $post_type_name = $this->post_type_name;
            $text_domain = $this->text_domain;
     
            // Taxonomy properties
            $name_arr = explode("_", $post_type_name);
            $temp_name = $name_arr[0] . '_' . $name;
            $taxonomy_name      = self::uglify( $temp_name );
            $taxonomy_labels    = $labels;
            $taxonomy_args      = $args;
     
            
            if( ! taxonomy_exists( $taxonomy_name ) ) {
                /* Create taxonomy and attach it to the object type (post type) */
                //Capitilize the words and make it plural
                $name       = self::beautify( $name );
                $plural     = self::pluralize( $name );
                 
                // Default labels, overwrite them with the given labels.
                $labels = array_merge(
                 
                    // Default

                    array(
                        'name'                       => _x( $plural, 'Taxonomy General Name', $text_domain ),
                        'singular_name'              => _x( $name, 'Taxonomy Singular Name', $text_domain ),
                        'menu_name'                  => __( $plural, $text_domain ),
                        'all_items'                  => __( 'All '. $plural, $text_domain ),
                        'parent_item'                => __( 'Parent '. $name, $text_domain ),
                        'parent_item_colon'          => __( 'Parent '.$name.':', $text_domain ),
                        'new_item_name'              => __( 'New '.$name.' Name', $text_domain ),
                        'add_new_item'               => __( 'Add New', $text_domain ),
                        'edit_item'                  => __( 'Edit', $text_domain ),
                        'update_item'                => __( 'Update', $text_domain ),
                        'separate_items_with_commas' => __( 'Separate with commas', $text_domain ),
                        'search_items'               => __( 'Search', $text_domain ),
                        'add_or_remove_items'        => __( 'Add or remove '. strtolower( $plural ), $text_domain ),
                        'choose_from_most_used'      => __( 'Choose from the most used '. strtolower( $plural ), $text_domain ),
                        'not_found'                  => __( 'Not Found', $text_domain )
                    ),
                 
                    // Given labels
                    $taxonomy_labels
                 
                );
                 
                // Default arguments, overwritten with the given arguments
                $args = array_merge(
                 
                    // Default

                    array(
                        'label'                      => __( $plural, $text_domain ),
                        'labels'                     => $labels,
                        'hierarchical'               => true,
                        'public'                     => true,
                        'show_ui'                    => true,
                        'show_admin_column'          => true,
                        'show_in_nav_menus'          => true,
                        'show_tagcloud'              => false,
                        'rewrite'                    => true,
                    ),
                 
                    // Given
                    $taxonomy_args
                 
                );
                 
                // Add the taxonomy to the post type
                add_action( 'init',
                    function() use( $taxonomy_name, $post_type_name, $args )
                    {
                        register_taxonomy( $taxonomy_name, $post_type_name, $args );
                    }
                );

            }
            else {
                /* The taxonomy already exists. We are going to attach the existing taxonomy to the object type (post type) */
                add_action( 'init',
                    function() use( $taxonomy_name, $post_type_name ){
                        register_taxonomy_for_object_type( $taxonomy_name, $post_type_name );
                    }
                );
            }
        }
    }

    public static function beautify( $string ) {
        return ucwords( str_replace( '_', ' ', $string ) );
    }
 
    public static function uglify( $string ) {
        return strtolower( str_replace( ' ', '_', $string ) );
    }

    public static function pluralize( $string ) {
        $last = $string[strlen( $string ) - 1];
         
        if( $last == 'y' ) {
            $cut = substr( $string, 0, -1 );
            //convert y to ies
            $plural = $cut . 'ies';
        }
        else {
            // just attach an s
            $plural = $string . 's';
        }
         
        return $plural;
    }

}


