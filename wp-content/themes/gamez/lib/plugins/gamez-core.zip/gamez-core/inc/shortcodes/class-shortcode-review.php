<?php
/**
 *
 * Review Shortcode
 *
 */


class Gamez_Shortcode_Review {


    /**
     *
     * Shortcode Name
     * @var string
     */

    private $name = 'gamez-review';

    private $post_type = 'game_review';

    /**
     * Instance of class
     */
    private static $instance;

    /**
     * Initialization
     */
    public static function init() {
        if ( null === self::$instance ) {
            self::$instance = new self;
        }

        return self::$instance;
    }


    private function __construct() {

        add_shortcode( $this->name, array( $this, 'create_review_shortcode' ) );
    }


    /**
     * Shortcode Function
     *
     * @param $atts
     * @return string
     */

    public function create_review_shortcode( $atts ) {

        ob_start();

        $option = array(
            'item' => 8,
            'order' => 'DESC',
            'orderby' => 'date',
            'style' => 'carousel',

        );

        $s = shortcode_atts( $option, $atts );

        $args = array(
            'post_type' => $this->post_type,
            'order' => $s['order'],
            'orderby' => $s['orderby'],
            'posts_per_page' => $s['item'],
        );

        $q = new WP_Query( $args );

        if ( $q->have_posts() ): ?>

            <?php    if ($s['style'] == 'carousel'):?>

                <div class="owl-carousel review-carousel">

                    <?php  while ( $q->have_posts() ): $q->the_post(); ?>
                        <?php
                        $post_id = get_the_ID();
                        $review_meta = get_post_meta( $post_id, '_tx_gamez_review', true );
                        $review_terms = get_the_terms( $post_id, 'game_genre' );
                        $review_verdict_rating = (float) gamez_array_get( $review_meta, '_tx_review_verdict_rating' );
                        $perma = get_permalink(); ?>


                        <div class="gamez-review-item-carousel">
                            <?php if(has_post_thumbnail()): ?>
                            <figure>
                                <?php the_post_thumbnail('large'); ?>
                                <a href="<?php echo $perma; ?>"><i class="flaticon-game-console-2"></i></a>
                            </figure>
                                <h3 class="review-item-title"><a href="<?php echo esc_url($perma); ?>"><?php the_title(); ?></a></h3>
                                <div class="review-item-meta">
                                    <span>
                                        <i class="fa fa-star"></i> <?php esc_html(printf( '%.1f / 10', $review_verdict_rating )); ?>
                                    </span>
                                    <span>
                                        <?php $count = 1;
                                        foreach ($review_terms as $term): ?>
                                            <?php if($count > 1) {
                                                echo ',';
                                            }
                                            $count++; ?>
                                            <a href="<?php echo esc_url(get_term_link( $term )); ?>"><?php echo esc_html($term->name); ?></a>
                                        <?php endforeach; ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                        </div>


                    <?php endwhile; wp_reset_postdata(); ?>
                </div>
            <?php endif; ?>

            <?php    if ($s['style'] == 'grid'):?>
                <div class="row">
                    <?php $review_counter = 1; ?>

                    <?php  while ( $q->have_posts() ): $q->the_post(); ?>
                        <?php
                        $post_id = get_the_ID();
                        $review_meta = get_post_meta( $post_id, '_tx_gamez_review', true );
                        $review_terms = get_the_terms( $post_id, 'game_genre' );
                        $review_verdict_rating = (float) gamez_array_get( $review_meta, '_tx_review_verdict_rating' );
                        $perma = get_permalink(); ?>

                        <div class="gamez-review-item-grid col-md-6">
                            <div class="media">
                                <?php if( has_post_thumbnail() ): ?>
                                    <div class="media-left">
                                        <figure>
                                            <?php the_post_thumbnail('medium'); ?>
                                        </figure>
                                    </div>
                                <?php endif; ?>
                                <div class="media-body">
                                    <div class="review-item-counter">
                                        <?php printf('%02d', $review_counter); ?>
                                    </div>
                                    <h3 class="review-item-title"><a href="<?php echo esc_url($perma); ?>"><?php the_title(); ?></a></h3>
                                    <div class="review-item-meta">
                                    <span>
                                        <i class="fa fa-star"></i> <?php esc_html(printf( '%.1f / 10', $review_verdict_rating )); ?>
                                    </span>
                                    <span>
                                        <?php $count = 1;
                                        foreach ($review_terms as $term): ?>
                                            <?php if($count > 1) {
                                                echo ',';
                                            }
                                            $count++; ?>
                                            <a href="<?php echo esc_url(get_term_link( $term )); ?>"><?php echo esc_html($term->name); ?></a>
                                        <?php endforeach; ?>
                                    </span>
                                    </div>
                                    <div class="review-item-continue-btn">
                                        <a href="<?php echo $perma; ?>"><i class="fa fa-arrow-right fa-fw"></i></a>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <?php if($review_counter % 2 == 0) {
                            echo '</div><div class="row">';
                        } ?>
                        <?php $review_counter++; ?>
                    <?php endwhile; wp_reset_postdata(); ?>
                </div>
            <?php endif; ?>



        <?php else: ?>

            <p> <?php esc_html_e( 'Sorry no post found.', 'gamez' ); ?> </p>

        <?php    endif;

        $output = ob_get_clean();

        return $output;

    }



}