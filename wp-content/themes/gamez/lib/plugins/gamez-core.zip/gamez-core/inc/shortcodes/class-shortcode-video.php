<?php

/*
* Woosome ajax tab
*/

class Gamez_Video_Tab
{

    private $name = 'video-tab';

    private static $instance;

    // initialization
    #================
    public static function init()
    {
        if (null == self::$instance) {
            self::$instance = new self;
        }
        return self::$instance;
    }

    // construct
    private function __construct()
    {
        add_shortcode($this->name, array($this, 'gamez_video_tab'));
    }


    public function gamez_video_tab($atts)
    {
        global $post;
        ob_start();
        $option = array(
            'no_video_tab' => '4',
            'type' => '',
        );

        $ab = shortcode_atts($option, $atts);

        $query = new WP_Query(
            array(
                'post_type' => 'video_gallery',
                'posts_per_page' => $ab['no_video_tab'],
            )
        );
        ?>



        <div class="gamez_ajax_tab">
            <div class="gamez-ajax-tab-wrapper">
            <?php if ($ab['type'] == 'horizontal'): ?>
                <div class="col-md-6 left-side">
            <?php elseif($ab['type'] == 'vertical'): ?>
                <div class="col-md-12 left-side">
            <?php endif; ?>

                    <div id="ajax-video-tab">
                        <div class="loader">
<!--                            loading icon -->
                            <div id="ajaxloader">
                                <div class="outer"></div>
                                <div class="inner"></div>
                            </div>
<!--                            end of loading icon-->
                        </div>
                    </div>
                </div>
<!--        end of /.left-side -->


            <?php if ($ab['type'] == 'horizontal'): ?>
                <div class="col-md-6 right-side cpt-video-lists">
            <?php elseif($ab['type'] == 'vertical'): ?>
                <div class="col-md-12 right-side cpt-video-lists list-vertical">
            <?php endif; ?>
                    <ul>
                        <?php if ($query->have_posts()): ?>
                            <?php while ($query->have_posts()): ?>
                                <?php $query->the_post(); ?>
                                <li>
                                    <?php $id = get_the_ID(); ?>
                                    <a class="video-url"
                                       href="<?php echo admin_url('admin-ajax.php?action=button_click&post_type=video_gallery&id=' . $id); ?>">
                                        <div class="video-icon">
                                            <!--                                            <span><i class="fa fa-play-circle-o"></i></span>-->
                                            <span class="gamez-play">
                                                <svg x="0px" y="0px" viewBox="0 0 213.7 213.7"
                                                     enable-background="new 0 0 213.7 213.7"
                                                     xml:space="preserve">
                                                    <polygon class='triangle' fill="none" stroke-width="7"
                                                             stroke-linecap="round"
                                                             stroke-linejoin="round" stroke-miterlimit="10"
                                                             points="73.5,62.5 148.5,105.8 73.5,149.1"></polygon>
                                                </svg>
                                            </span>
                                        </div>
                                        <div class="video-content-wrapper">
                                            <h3 class="video-title"><?php the_title(); ?></h3>
                                            <div class="video-content"><?php echo wp_trim_words(get_the_content(), $num_words = 8, $more = null);; ?></div>
                                        </div>

                                    </a>
                                </li>
                            <?php endwhile; ?>
                        <?php endif; ?>
                        <?php wp_reset_postdata(); ?>

                    </ul>

                </div>
<!--        end of /.right-side-->
            </div>
<!--        end of /.gamez-ajax-tab-wrapper-->
        </div>
        <!-- end of the div/.gamez_ajax_tab -->
        <?php

        $output = ob_get_clean();
        return $output;
    }

}