<?php
/**
 *
 * Mailchimp Form Shortcode
 *
 */


class Gamez_Custom_Login {


    /**
     *
     * Shortcode Name
     * @var string
     */

    private $name_reg = 'gamez_custom_registration';


    /**
     * Instance of class
     */
    private static $instance;

    /**
     * Initialization
     */
    public static function init() {
        if ( null === self::$instance ) {
            self::$instance = new self;
        }

        return self::$instance;
    }


    private function __construct() {
        add_shortcode( $this->name_reg, array( $this, 'custom_registration_shortcode' ) );
    }


    /**
     * Shortcode Function
     *
     * @param $atts
     * @return string
     */





    public function registration_form( $username, $password, $email ) {


        echo '
    <form class="custom-register-form" action="' . $_SERVER['REQUEST_URI'] . '" method="post">



	<div class="reg-section">
        <label for="username" class="">'. esc_html__( 'Username', 'gamez' ) .'</label>
        <input class="" type="text" name="username" value="' . (isset($_POST['username']) ? $username : null) . '">
    </div>

    <div class="reg-section">
        <label for="password" class="">'. esc_html__( 'Password', 'gamez' ) .'</label>
        <input class="" type="password" name="password" value="' . (isset($_POST['password']) ? $password : null) . '">
    </div>


	<div class="reg-section">
        <label for="email" class="">'. esc_html__( 'Email', 'gamez' ) .'</label>
        <input class="" type="email" name="email" value="' . (isset($_POST['email']) ? $email : null) . '">
    </div>



	<div class="reg-section">
       <input class="btn btn-primary btn-special" type="submit" name="submit" value="'. esc_attr__( 'Register', 'gamez' ) .'"/>
  </div>

	</form>

	';
    }

    public function registration_validation( $username, $password, $email)  {
        global $reg_errors;
        $reg_errors = new WP_Error;

        if ( empty( $username ) || empty( $password ) || empty( $email ) ) {
            $reg_errors->add('field', 'Required form field is missing');
        }

        if ( strlen( $username ) < 4 ) {
            $reg_errors->add('username_length', 'Username too short. At least 4 characters is required');
        }

        if ( username_exists( $username ) )
            $reg_errors->add('user_name', 'Sorry, that username already exists!');

        if ( !validate_username( $username ) ) {
            $reg_errors->add('username_invalid', 'Sorry, the username you entered is not valid');
        }

        if ( strlen( $password ) < 5 ) {
            $reg_errors->add('password', 'Password length must be greater than 5');
        }

        if ( !is_email( $email ) ) {
            $reg_errors->add('email_invalid', 'Email is not valid');
        }

        if ( email_exists( $email ) ) {
            $reg_errors->add('email', 'Email Already in use');
        }



        if ( is_wp_error( $reg_errors ) ) {

            foreach ( $reg_errors->get_error_messages() as $error ) {
                echo '<div>';
                echo '<strong>ERROR</strong>:';
                echo $error . '<br/>';

                echo '</div>';
            }
        }
    }

    public function complete_registration() {
        global $reg_errors, $username, $password, $email, $website, $first_name, $last_name, $nickname, $bio;
        if ( count($reg_errors->get_error_messages()) < 1 ) {
            $userdata = array(
                'user_login'	=> 	$username,
                'user_email' 	=> 	$email,
                'user_pass' 	=> 	$password,

            );
            $user = wp_insert_user( $userdata );
            echo 'Registration complete. Goto <a href="' . get_site_url() . '/wp-login.php">login page</a>.';
        }
    }

    public function custom_registration_function() {
        global $username, $password, $email;


        if (isset($_POST['submit'])) {
            $this->registration_validation(
                $_POST['username'],
                $_POST['password'],
                $_POST['email']

            );

            // sanitize user form input

            $username	= 	sanitize_user($_POST['username']);
            $password 	= 	esc_attr($_POST['password']);
            $email 		= 	sanitize_email($_POST['email']);

            // call @function complete_registration to create the user
            // only when no WP_error is found
            $this->complete_registration(
                $username,
                $password,
                $email

            );
        }

        $this->registration_form(
            $username,
            $password,
            $email

        );
    }


    public function custom_registration_shortcode() {
        ob_start();
        $this->custom_registration_function();
        return ob_get_clean();
    }


}