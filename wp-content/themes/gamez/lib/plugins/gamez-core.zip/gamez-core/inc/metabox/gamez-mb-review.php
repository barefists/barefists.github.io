<?php

/**
 *
 * Review Metabox
 *
 */


function gamez_review_metabox( $options ){


    $options      = array();

    $options[]    = array(
        'id'        => '_tx_gamez_review',
        'title'     => __('Game Information', 'gamez'),
        'post_type' => 'game_review',
        'context'   => 'normal',
        'priority'  => 'default',
        'sections'  => array(

            array(
                'name'   => '_tx_review_header',
                'title'  => __('Header', 'gamez'),
                'fields' => array(
                    array(
                        'id'    => '_tx_review_header_cover',
                        'type'  => 'image',
                        'title' => __('Cover Image', 'gamez'),
                        'desc'  => __('Select an image for header area.', 'gamez')
                    ),

                    array(
                        'id'    => '_tx_review_header_video',
                        'type'  => 'text',
                        'title' => __('Popup Video Link', 'gamez'),
                        'desc'  => __('Trailer or Game video youtube or vimeo link. If you do not want to add video just leave it empty.', 'gamez')
                    )

                )
            ),

            array(
                'name'   => '_tx_review_info',
                'title'  => __('Basic Info', 'gamez'),
                'fields' => array(

                    array(
                        'id'         => '_tx_review_info_platform',
                        'type'       => 'checkbox',
                        'title'      => __('Available Platforms', 'gamez'),
                        'options'    => array(
                            'ps4'          => 'PS4',
                            'xbox_one'     => 'Xbox One',
                            'wii'      => 'Wii U',
                            '3ds'      => '3DS',
                            'steam'    => 'Steam',
                            'windows'  => 'Windows',
                            'osx'      => 'Mac OSX',
                            'mobile'   => 'Mobile'
                        ),
                    ),
                    
                    array(
                        'id'    => '_tx_review_info_release',
                        'type'  => 'text',
                        'title' => __('Release Date', 'gamez'),
                        'desc'  => __('Release Date of the game.', 'gamez')
                    ),
                    array(
                        'id'    => '_tx_review_info_developer',
                        'type'  => 'text',
                        'title' => __('Developer', 'gamez'),
                        'desc'  => __('Developer of the game.', 'gamez')
                    ),
                    array(
                        'id'    => '_tx_review_info_publisher',
                        'type'  => 'text',
                        'title' => __('Publisher', 'gamez'),
                        'desc'  => __('Publisher of the game.', 'gamez')
                    ),

                    array(
                        'id'    => '_tx_review_info_desc',
                        'type'  => 'wysiwyg',
                        'title' => __('Game Descriptions', 'gamez'),
                        'desc'  => __('Write something about the game.', 'gamez'),
                        'settings' => array(
                            'textarea_rows' => 10,
                            'tinymce'       => false,
                            'media_buttons' => false,
                        )
                    ),

                )
            ),

            array(
                'name'   => '_tx_review_deals',
                'title'  => __('Deals', 'gamez'),
                'fields' => array(
                    array(
                        'type'    => 'subheading',
                        'content' => __('Add your affiliated product info.', 'gamez'),
                    ),

                    array(
                        'id'              => '_tx_review_deals_store',
                        'type'            => 'group',
                        'title'           => __('Store', 'gamez'),
                        'button_title'    => __('Add New', 'gamez'),
                        'accordion_title' => __('Add New Store', 'gamez'),
                        'fields'          => array(
                            array(
                                'id'             => '_tx_review_deals_site',
                                'type'           => 'select',
                                'title'          =>  __('Site', 'gamez'),
                                'options'        => array(
                                    'amazon'          => 'Amazon',
                                    'gameseek'        => 'Game Seek',
                                    'glyde'           => 'Glyde',
                                    'estarland'       => 'eStarland',
                                    'jjgames'         => 'JJGames',
                                    'gamersgate'      => 'GamersGate',
                                    'gamestop'        => 'GameStop',
                                    'bestbuy'         => 'Best Buy',
                                    'geenmangamming'  => 'Green Man Gaming',
                                    'zavvi'           => 'Zavvi',
                                    'walmart'         => 'Walmart',
                                ),
                                'default_option' => __('Select a Site', 'gamez'),
                            ),
                            array(
                                'id'    => '_tx_review_deals_price',
                                'type'  => 'text',
                                'title' => __('Price', 'gamez'),
                                'desc'  => __('Price of game.', 'gamez')
                            ),

                            array(
                                'id'    => '_tx_review_deals_price_currency',
                                'type'  => 'text',
                                'title' => __('Currency', 'gamez'),
                                'desc'  => __('Currency of price.', 'gamez'),
                                'default' => '$'
                            ),

                            array(
                                'id'    => '_tx_review_deals_link',
                                'type'  => 'text',
                                'title' => __('Game Link', 'gamez'),
                                'desc'  => __('Product link of your affiliation site.', 'gamez')
                            )
                        )
                    )
                )
            ),

            array(
                'name'   => '_tx_review_verdict',
                'title'  => __('Verdict', 'gamez'),
                'fields' => array(
                    array(
                        'id'    => '_tx_review_verdict_cover',
                        'type'  => 'image',
                        'title' => __('Section Background', 'gamez'),
                        'desc'  => __('Select an image for section background.', 'gamez')
                    ),

                    array(
                        'id'    => '_tx_review_verdict_rating',
                        'type'  => 'text',
                        'title' => __('Rating', 'gamez'),
                        'desc'  => __('Your rating for this game(0-10). You can add real number.', 'gamez')
                    ),

                    array(
                        'id'              => '_tx_review_verdict_positive',
                        'type'            => 'group',
                        'title'           => __('Pros', 'gamez'),
                        'button_title'    => __('Add New', 'gamez'),
                        'accordion_title' => __('Add New Pros', 'gamez'),
                        'fields'          => array(
                            array(
                                'id'    => '_tx_review_verdict_positive_verdict',
                                'type'  => 'text',
                                'title' => __('Verdict', 'gamez'),
                                'desc'  => __('Add your positive verdict.', 'gamez')
                            ),
                        )
                    ),
                    array(
                        'id'              => '_tx_review_verdict_negative',
                        'type'            => 'group',
                        'title'           => __('Cons', 'gamez'),
                        'button_title'    => __('Add New', 'gamez'),
                        'accordion_title' => __('Add New Cons', 'gamez'),
                        'fields'          => array(
                            array(
                                'id'    => '_tx_review_verdict_negative_verdict',
                                'type'  => 'text',
                                'title' => __('Verdict', 'gamez'),
                                'desc'  => __('Add your negative verdict.', 'gamez')
                            ),
                        )
                    )

                )
            ),

            array(
                'name'   => '_tx_review_images',
                'title'  => __('Images', 'gamez'),
                'fields' => array(
                    array(
                        'id'          => '_tx_review_image_gallery',
                        'type'        => 'gallery',
                        'title'       => __('Image Gallery', 'gamez'),
                        'desc'        => __('Image gallery of this game.', 'gamez'),
                        'add_title'   => __('Add Images', 'gamez'),
                        'edit_title'  => __('Edit Images', 'gamez'),
                        'clear_title' => __('Remove Images', 'gamez'),
                    )

                )
            ),

            array(
                'name'   => '_tx_review_videos',
                'title'  => __('Videos', 'gamez'),
                'fields' => array(
                    array(
                        'id'              => '_tx_review_video_gallery',
                        'type'            => 'group',
                        'title'           => __('Video Gallery', 'gamez'),
                        'button_title'    => __('Add New', 'gamez'),
                        'accordion_title' => __('Add New Video', 'gamez'),
                        'fields'          => array(
                            array(
                                'id'    => '_tx_review_video_gallery_link',
                                'type'  => 'text',
                                'title' => __('Video Link', 'gamez'),
                                'desc'  => __('Enter vimeo or youtube video link.', 'gamez')
                            ),
                            array(
                                'id'    => '_tx_review_video_gallery_cover',
                                'type'  => 'image',
                                'title' => __('Video Cover', 'gamez'),
                                'desc'  => __('Upload video cover image.', 'gamez')
                            ),

                        )
                    ),
                )
            ),

        )
    );

    return $options;

}


add_filter( 'cs_metabox_options',  'gamez_review_metabox');

