<?php

/*
 *
 *  All Custom Post Type for Gamez
 *
 */


// Text Domain
$text_domain = 'gamez';

/*
 *  Game Review
 */
$games_label = array();
$games_args = array(
    'menu_icon'             => 'dashicons-performance',
    'supports'              => array( 'title', 'editor', 'thumbnail', 'comments' ),
    'rewrite'               => array(
        'slug'      => 'review'
    ),
);
$games_genre_label = array();
$games_genre_args = array(
    'rewrite'   => array(
        'slug'    => 'genre'
    ),
);
$games_review = new Tx_Custom_Post_Type('Game Review', $games_args, $games_label , $text_domain);
$games_review->add_taxonomy( 'Genre', $games_genre_args, $games_genre_label );


/*
 *  Video Gallery
 */
$gallery_label = array();
$gallery_args = array(
    'menu_icon'             => 'dashicons-format-video',
    'rewrite'               => array(
        'slug'      => 'video-gallery'
    ),
);
$gallery_cat_label = array();
$gallery_cat_args = array(
    'rewrite'   => array(
        'slug'    => 'video-category'
    ),
);
$video_gallery = new Tx_Custom_Post_Type('Video Gallery', $gallery_args, $gallery_label , $text_domain);
$video_gallery->add_taxonomy( 'Category', $gallery_cat_args, $gallery_cat_label );
