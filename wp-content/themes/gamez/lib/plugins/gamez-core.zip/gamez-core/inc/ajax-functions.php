<?php
/**
 * ajax implement
 * for video gallery
 */
add_action( 'wp_ajax_nopriv_button_click', 'user_clicked' );
add_action( 'wp_ajax_button_click', 'user_clicked' );

function user_clicked() {
    global $post, $data;
    $data = $_REQUEST['id'];
    $query = new WP_Query(
        array(
            'post_type' => 'video_gallery',
            'p'	=> $data,
        )
    );
    ?>

    <div class="video-single">
        <div class="video-single-gallery">
            <?php
            if($query->have_posts()):
                while ($query->have_posts()):
                    $query->the_post();
                    $video_links = get_post_meta($post->ID, '_tx_video_gallery', true);
                    $video_links = $video_links['_tx_video_galleries'];

                    foreach($video_links as $video): ?>
                        <div class="video-gallery-item">
                            <?php echo wp_get_attachment_image($video['_tx_video_gallery_cover'], 'large', false, array('class' => 'img-responsive')); ?>
                            <a href="<?php echo esc_url($video['_tx_video_gallery_link']); ?>" class="popup-video gamez-play">
                                <svg x="0px" y="0px" viewBox="0 0 213.7 213.7" enable-background="new 0 0 213.7 213.7"
                                     xml:space="preserve">
									<polygon class='triangle' fill="none" stroke-width="7" stroke-linecap="round"
                                             stroke-linejoin="round" stroke-miterlimit="10"
                                             points="73.5,62.5 148.5,105.8 73.5,149.1">
                                    </polygon>
								</svg>
                            </a>
                        </div>
                    <?php endforeach;
                endwhile; wp_reset_postdata();
            endif;
            ?>
        </div>
    </div>
    <?php
    die();
}
