<?php


class Gamez_VC_Init {


    function __construct() {
        // We safely integrate with VC with this hook
        add_action('init', array($this, 'gamez_vc_integration'));


        // Register CSS and JS
        //add_action('wp_enqueue_scripts', array($this, 'loadCssAndJs'));
    }

    public function gamez_vc_integration() {
        // Check if Visual Composer is installed
        if (!defined('WPB_VC_VERSION')) {
            // Display notice that Visual Compser is required
            add_action('admin_notices', array($this, 'showVcVersionNotice'));
            return;
        }


        /**
        * Most used elements in shortcode
        */

        /**
         * @var string Appica icon for all shortcodes
         */
        $icon = plugins_url( 'assets/images/gamez-icon.png', __DIR__ );

        /**
         * @var string Shortcodes global category
         */
        $category = __( 'Gamez', 'gamez' );

        /**
         * @var string Shortcodes title i18n single call
         */
        $heading_title = __( 'Title', 'gamez' );

        /**
         * @var string Shortcodes subtitle i18n single call
         */
        $heading_subtitle = __( 'Subtitle', 'gamez' );

        /**
         * @var string Icon heading name
         */
        $heading_icon = __( 'Icon', 'gamez' );

        /**
         * @var array Yes/No dropdown value
         */
        $value_yes_no = array(
            __( 'Yes', 'gamez' ) => 'yes',
            __( 'No', 'gamez' )  => 'no'
        );

        /**
         * @var array Left/Right dropdown value
         */
        $value_left_right = array(
            __( 'Left', 'gamez' )  => 'left',
            __( 'Right', 'gamez' ) => 'right'
        );

        /**
         * @var array ASC/DESC dropdown value
         */
        $value_asc_desc = array(
            __( 'Ascending', 'gamez' )  => 'ASC',
            __( 'Descending', 'gamez' ) => 'DESC'
        );


        /**
         * @var array "Enable/Disable" dropdown value
         */
        $value_enable_disable = array(
            __( 'Enable', 'gamez' ) => 'enable',
            __( 'Disable', 'gamez' ) => 'disable'
        );



        /**
         *
         * VC Tab Group
         *
         */

        $general = __( 'General', 'gamez' );
        $design = __( 'Design', 'gamez' );


        /**
        Add your Visual Composer logic here.
        Lets call vc_map function to "register" our custom shortcode within Visual Composer interface.
        */


        include GAMEZ_CORE_ROOT . '/inc/vc-addons/vc-gamez-recentpost.php';
        include GAMEZ_CORE_ROOT . '/inc/vc-addons/vc-gamez-video-tab.php';
        include GAMEZ_CORE_ROOT . '/inc/vc-addons/vc-gamez-review.php';
        include GAMEZ_CORE_ROOT . '/inc/vc-addons/vc-gamez-featured-product.php';
        include GAMEZ_CORE_ROOT . '/inc/vc-addons/vc-gamez-recentproduct.php';
        include GAMEZ_CORE_ROOT . '/inc/vc-addons/vc-gamez-bestsellingproduct.php';
        include GAMEZ_CORE_ROOT . '/inc/vc-addons/vc-gamez-title.php';

        vc_map( $gamez_recent_post_mapper );
        vc_map( $gamez_video_tab );
        vc_map( $gamez_review_mapper );

        vc_map( $vc_gamez_feaured_product ); // class for vc featured product addon
        vc_map( $vc_gamez_recent_product ); // class for vc recent product addon
        vc_map( $vc_gamez_bestselling_product ); // class for vc bestselling product addon
        vc_map( $gamez_title_mapper );



    }
    

    /**
    Show notice if your plugin is activated but Visual Composer is not
    */
    public function showVcVersionNotice() {
        $plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated.', 'gamez'), $plugin_data['Name']).'</p>
        </div>';
    }



}

// Finally initialize code
new Gamez_VC_Init();
